def get_srid():
    """
    Get the project SRID. Currently only supports 4326.
    """
    return 4326
